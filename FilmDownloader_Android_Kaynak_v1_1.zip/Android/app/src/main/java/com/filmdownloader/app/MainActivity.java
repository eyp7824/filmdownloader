package com.filmdownloader.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView browser;
    private EditText address;
    private TextView status;
    private ProgressBar progress;
    private ValueCallback<Uri[]> fileCallback;
    private static final int PICK_FILE = 301;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(12, 12, 12, 8);
        page.setBackgroundColor(Color.WHITE);
        TextView title = new TextView(this);
        title.setText("FİLM DOWNLOADER"); title.setTextSize(24);
        title.setTextColor(Color.rgb(0, 110, 130));
        page.addView(title);
        address = new EditText(this);
        address.setSingleLine(true); address.setTextSize(17);
        address.setHint("Web sitesi veya doğrudan dosya adresi");
        page.addView(address);
        LinearLayout buttons = new LinearLayout(this);
        Button go = new Button(this); go.setText("Siteye git");
        buttons.addView(go, new LinearLayout.LayoutParams(0, -2, 1));
        Button direct = new Button(this); direct.setText("URL indir");
        buttons.addView(direct, new LinearLayout.LayoutParams(0, -2, 1));
        Button downloads = new Button(this); downloads.setText("İndirilenler");
        buttons.addView(downloads, new LinearLayout.LayoutParams(0, -2, 1));
        page.addView(buttons);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100); page.addView(progress);
        status = new TextView(this); status.setTextSize(16); status.setTextColor(Color.DKGRAY);
        status.setText("İndirilebilir bağlantıları açın veya doğrudan dosya URL'si girin.");
        page.addView(status);
        browser = new WebView(this);
        WebSettings settings = browser.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false); settings.setAllowContentAccess(true);
        CookieManager.getInstance().setAcceptCookie(true);
        browser.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) { address.setText(url); }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) status.setText("Sayfa açılamadı: " + error.getDescription());
            }
        });
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) { progress.setProgress(value); }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try { startActivityForResult(params.createIntent(), PICK_FILE); return true; }
                catch (Exception ex) { fileCallback = null; return false; }
            }
        });
        browser.setDownloadListener((url, userAgent, disposition, mime, length) -> download(url, userAgent, mime, disposition));
        page.addView(browser, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(page);
        go.setOnClickListener(v -> {
            String url = address.getText().toString().trim();
            if (!url.startsWith("https://") && !url.startsWith("http://")) url = "https://" + url;
            browser.loadUrl(url);
        });
        direct.setOnClickListener(v -> download(address.getText().toString().trim(), null, null, null));
        downloads.setOnClickListener(v -> {
            try { startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); }
            catch (Exception ex) { status.setText("İndirmeler ekranı açılamadı."); }
        });
        Intent incoming = getIntent();
        if (Intent.ACTION_SEND.equals(incoming.getAction()) && "text/plain".equals(incoming.getType())) {
            String shared = incoming.getStringExtra(Intent.EXTRA_TEXT);
            if (shared != null) address.setText(shared.trim());
        }
    }

    private void download(String url, String agent, String mime, String disposition) {
        Uri uri;
        try {
            uri = Uri.parse(url);
            if (!"https".equalsIgnoreCase(uri.getScheme()) && !"http".equalsIgnoreCase(uri.getScheme())) throw new Exception();
        } catch (Exception ex) {
            Toast.makeText(this, "Geçerli HTTP/HTTPS bağlantısı girin.", Toast.LENGTH_LONG).show(); return;
        }
        String filename = URLUtil.guessFileName(url, disposition, mime);
        new AlertDialog.Builder(this).setTitle("Dosyayı indir?")
            .setMessage(filename + "\n\nYalnızca indirme izniniz bulunan dosyaları kaydedin.")
            .setNegativeButton("Vazgeç", null).setPositiveButton("İndir", (dialog, which) -> {
                try {
                    DownloadManager.Request request = new DownloadManager.Request(uri);
                    request.setTitle(filename);
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
                    if (agent != null && !agent.isEmpty()) request.addRequestHeader("User-Agent", agent);
                    String cookies = CookieManager.getInstance().getCookie(url);
                    if (cookies != null && !cookies.isEmpty()) request.addRequestHeader("Cookie", cookies);
                    String referer = browser.getUrl();
                    if (referer != null && (referer.startsWith("https://") || referer.startsWith("http://"))) request.addRequestHeader("Referer", referer);
                    ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(request);
                    status.setText("İndirme kuyruğuna eklendi: " + filename);
                } catch (Exception ex) { status.setText("İndirme hatası: " + ex.getMessage()); }
            }).show();
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            fileCallback = null;
        }
    }
    @Override public void onBackPressed() { if (browser.canGoBack()) browser.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { browser.destroy(); super.onDestroy(); }
}
